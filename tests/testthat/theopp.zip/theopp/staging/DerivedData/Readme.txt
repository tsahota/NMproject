Directory for derived analysis-ready datasets
