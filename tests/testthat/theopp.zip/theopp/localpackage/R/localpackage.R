#' Local package
#' 
#' This is a package local to only this project
#' 
#' @name localpackage
#' @examples 
#' \dontrun{
#' 
#' ## load functions with:
#' load_localpackage()
#' 
#' }

NULL
