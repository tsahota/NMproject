Directory for NONMEM runs and other 3rd party software
