This folder is for modelling performed outside of R (i.e. in 3rd party software)
