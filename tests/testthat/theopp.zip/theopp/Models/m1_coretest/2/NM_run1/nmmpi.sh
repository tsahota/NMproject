mpirun -wdir "$PWD" -n 1 ./nonmem  $* : \
-wdir "$PWD/worker1" -n 1 ./nonmem
