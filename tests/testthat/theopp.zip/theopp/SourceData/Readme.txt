This directory is for unmodified source datasets.  Data in this directory should not be modified.
