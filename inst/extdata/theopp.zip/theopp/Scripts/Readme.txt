Directory for R and Rmd scripts
