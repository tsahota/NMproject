Directory for unmodified source data
